package cz.upce.inpia.simpleshop.products;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InpiaSimpleShopProductsApplication {

    public static void main(String[] args) {
        SpringApplication.run(InpiaSimpleShopProductsApplication.class, args);
    }

}

