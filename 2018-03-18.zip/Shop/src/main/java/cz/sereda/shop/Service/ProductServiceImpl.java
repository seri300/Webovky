package cz.sereda.shop.Service;

import cz.sereda.shop.Dao.ProductDao;
import cz.sereda.shop.Product;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.NoSuchElementException;

public class ProductServiceImpl  implements ProductService{
    private  final ProductDao productDao;

    @Autowired
    public ProductServiceImpl(ProductDao productDao) {this.productDao = productDao;}

    @Override
    public List<Product> findAll() {return productDao.findAll();}

    @Override
    public Product findById(Integer productId){
        if (productDao.findById(productId).isPresent()){
            return productDao.findById(productId).get();
        }
        else {
            throw new NoSuchElementException("Product s ID: " + productId + "nebyl najit");
        }
    }
}
