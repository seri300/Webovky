package cz.sereda.shop.Service;

import cz.sereda.shop.Dao.OrderFormDao;
import cz.sereda.shop.Dao.OrderedProductDao;
import cz.sereda.shop.OrderForm;
import cz.sereda.shop.OrderProduct;
import cz.sereda.shop.OrderState;
import cz.sereda.shop.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;

import javax.transaction.Transactional;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Service
@Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
@Transactional
public class CartServiceImpl implements CartService {
    private OrderFormDao orderFormDao;
    private final OrderedProductDao orderedProductDao;

    private Map<Product, Integer> cart = new HashMap<>();

    @Autowired
    public CartServiceImpl(OrderedProductDao orderedProductDao, OrderFormDao orderFormDao){
        this.orderedProductDao = orderedProductDao;
        this.orderFormDao = orderFormDao;
    }

    @Override
    public void addProductToCart(Product product){
        if(cart.containsKey(product)){
            cart.replace(product,cart.get(product)+1);
        }
        else {
            cart.put(product,1);
        }
    }

    @Override
    public void removeProductFromCart(Product product){
        if (cart.containsKey(product)){
            if (cart.get(product)>1)
                cart.replace(product,cart.get(product)-1);
            else if (cart.get(product)==1) {
                cart.remove(product);
            }
        }
    }

    @Override
    public Map<Product, Integer> getCart() {return Collections.unmodifiableMap(cart);}

    @Override
    public void checkout(){
        OrderForm orderForm = new OrderForm();
        orderForm.setOrderProducts(OrderState.NEW);
        orderFormDao.save(orderForm);

        for(Map.Entry<Product,Integer> entry : cart.entrySet()){
            OrderProduct orderedProduct = new OrderProduct();
            orderedProduct.setOrder(orderForm);
            orderedProduct.setProduct(entry.getKey());
            orderedProduct.setAmount(entry.getValue());
            orderedProductDao.save(orderProduct);
        }
        orderedProductDao.flush();
        cart.clear();
    }

}
