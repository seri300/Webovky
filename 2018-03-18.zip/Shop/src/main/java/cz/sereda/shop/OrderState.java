package cz.sereda.shop;

public enum OrderState {
    NEW,
    IN_DELIVERY,
    DELIVERED,
    CANCELED,
    ARCHIVED
}
