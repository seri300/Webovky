package cz.sereda.shop;

import cz.sereda.shop.Base.Base;
import lombok.Data;
import org.springframework.data.repository.cdi.Eager;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
@Data
public class OrderProduct extends Base {

    @ManyToOne()
    private OrderForm order;

    @ManyToOne()
    private Product product;

    @Column
    private  Integer amount;

    public OrderForm getOrder() {
        return order;
    }

    public  void setOrder(OrderForm order){
        this.order = order;
    }

    public  Product getProduct() {return product;}
    public void setProduct(Product product){this.product = product;}
    public  Integer getAmount() {return amount;}
    public void setAmount(Integer amount){this.amount = amount;}
}
