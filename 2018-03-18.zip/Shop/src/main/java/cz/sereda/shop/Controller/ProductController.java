package cz.sereda.shop.Controller;

import cz.sereda.shop.Dao.ProductDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class ProductController {

    private ProductDao productService;

    @Autowired
    public ProductController(ProductDao productService) {this.productService = productService;}

    @GetMapping("/")
    public String showAllProduct(Model model){
        model.addAttribute("productList", productService.findAll());
        return "product-list";
    }

    @GetMapping("/product/detail/")
    public String showAllDetail(Model model){
        model.addAttribute("productList", productService.findAll());
        return "product-list";
    }


}
