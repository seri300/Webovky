package cz.sereda.shop;

import cz.sereda.shop.Base.Base;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.OneToMany;
import java.util.Set;

@Entity
@Data
public class OrderForm extends Base {

    @OneToMany(mappedBy = "id")
    private Set<OrderProduct> orderProducts;

    @Enumerated(EnumType.STRING)
    private OrderState orderState;

    public Set<OrderProduct> getOrderProducts(){
        return orderProducts;
    }

    public void setOrderedProducts(Set<OrderProduct> orderedProducts){
        this.orderProducts = orderedProducts;
    }

    public OrderState getOrderState(){
        return orderState;
    }

    public void setOrderProducts(OrderState orderState){
        this.orderState = orderState;
    }


}
