package cz.sereda.shop.Service;

import cz.sereda.shop.Product;

import java.util.Map;

public interface CartService {

    void addProductToCart(Product product);
    void removeProductFromCart(Product product);
    Map<Product, Integer> getCart();
    void checkout();
}
