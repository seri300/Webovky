package cz.sereda.shop.Dao;

import cz.sereda.shop.OrderForm;
import cz.sereda.shop.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderedProductDao extends JpaRepository<Product, Integer> {
}
