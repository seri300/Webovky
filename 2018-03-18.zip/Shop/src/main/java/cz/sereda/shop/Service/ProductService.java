package cz.sereda.shop.Service;

import cz.sereda.shop.Product;

import java.util.List;

public interface ProductService {

    List<Product> findAll();
    Product findById(Integer productId);
}
