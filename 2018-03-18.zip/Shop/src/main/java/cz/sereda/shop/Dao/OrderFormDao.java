package cz.sereda.shop.Dao;

import cz.sereda.shop.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderFormDao extends JpaRepository<Product, Integer> {
}
