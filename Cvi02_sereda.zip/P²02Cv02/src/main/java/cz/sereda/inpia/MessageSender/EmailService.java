package cz.sereda.inpia.MessageSender;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;


@Component
public class EmailService implements MessageSender {
    public void sendMessage(String msg, String recipient) {
        System.out.println("Sending " + msg +
                " message to: " + recipient);
    }

    @PostConstruct
    public void loadCache() {
        System.out.println("Loading Cache");
    }
}
