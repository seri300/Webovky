package cz.sereda.inpia;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import cz.sereda.inpia.MessageSender.EmailService;

@Component
public class Application {

    @Autowired
    EmailService sender;

    public void processMessages(String msg, String recipient) {


        if (msg == null) {
            throw new IllegalArgumentException("Message is null");
        }
        sender.sendMessage(msg, recipient);
    }

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext("cz.sereda.inpia");
        Application application = context.getBean(Application.class);
        application.processMessages("Hello", "Pavel");
    }


}
