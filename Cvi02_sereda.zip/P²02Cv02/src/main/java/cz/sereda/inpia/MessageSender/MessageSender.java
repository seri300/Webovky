package cz.sereda.inpia.MessageSender;


public interface MessageSender {
    void sendMessage(String msg, String recipient);
}
