package cz.sereda.inpia.MessageSender;

import org.springframework.stereotype.Component;

/**
 * @author Tomas Kodym
 */
@Component
public class SMSService implements MessageSender {
    public void sendMessage(String msg, String recipient) {
        System.out.println("Sending SMS" + msg +
                " message to: " + recipient);
    }
}
