package cz.sereda.inpia;


import org.junit.Assert;
import org.junit.Test;

import cz.sereda.inpia.MessageSender.EmailService;

public class ApplicationTest {

    @Test
    public void processMessagesMsgEmptyTest() {
        Application application = new Application();
        application.sender = new EmailService();
        try {
            application.processMessages(null, "Tomas");
        } catch (IllegalArgumentException e) {
            System.out.println("Exception was catched.");
        }

    }

    @Test
    public void processMessagesMsgNotEmptyTest() {
        Application application = new Application();
        application.sender = new EmailService();
        EmailServiceMock emailServiceMock = new EmailServiceMock();
        application.sender = emailServiceMock;
        application.processMessages("Tomas", "Tomas");
        Assert.assertEquals("Expect 1 call to Email sender", 1, emailServiceMock.callCount);

    }

    //Inner class used for mocking
    private class EmailServiceMock extends EmailService {
        int callCount = 0;

        @Override
        public void sendMessage(String msg, String recipient) {
            super.sendMessage(msg, recipient);
            callCount++;
        }
    }
}