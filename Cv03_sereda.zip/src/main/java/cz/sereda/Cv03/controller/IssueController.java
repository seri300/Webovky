package cz.sereda.Cv03.controller;

import cz.sereda.Cv03.dao.IssueReport;
import org.hibernate.validator.constraints.URL;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class IssueController {

    @GetMapping("/issuereport")
    public String issueReport(Model model){
        model.addAttribute("issueReport", new IssueReport());
        return "issues/issuereport_form";

    }@GetMapping("/issues")
    public String issues(Model model){
        List<IssueReport>
        model.addAttribute("issueReport", new IssueReport());
        return "issues/issuereport_form";
    }

    @PostMapping("/issuereport")
    public String issueReportSubmit(IssueReport issueReport){
        System.out.println("Submitted" + issueReport.getDescription());
        return "redirect:/issuereport";
    }

/*    @GetMapping("/issue")
    public String getIssue(){
        return "issues/issuereport_list";
    }*/
}
