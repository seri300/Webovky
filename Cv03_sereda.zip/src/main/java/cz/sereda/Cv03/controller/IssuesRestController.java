package cz.sereda.Cv03.controller;

import cz.sereda.Cv03.dao.IssueReport;
import cz.sereda.Cv03.dao.IssueReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

public class IssuesRestController {

    @Autowired
    IssueReportRepository issueReportRepository;

    @GetMapping("/api/issue/list")
    public List<IssueReport> issues(){
        return issueReportRepository.findAll();
    }
}
