package cz.sereda.Cv03.dao;

import cz.sereda.Cv03.dao.IssueReport;
import cz.sereda.Cv03.dao.IssueReportRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.transaction.Transactional;
import java.util.Optional;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@DataJpaTest
public class IssueReportRepositoryTest {

    @Autowired
    IssueReportRepository issueReportRepository;

    @Test
    @Transactional
    public void testSave(){
        IssueReport report = new IssueReport();
        report.setDescription("test");
        report.setUrl("url");
        issueReportRepository.save(report);

        Long id = report.getId();
        assertNotNull(id);

        Optional<IssueReport> fromOb = issueReportRepository.findById(id);
        assertNotEquals(fromOb.get().getDescription(),"test");
    }

}